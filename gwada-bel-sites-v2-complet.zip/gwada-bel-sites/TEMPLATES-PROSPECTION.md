# 📧 Templates d'emails de prospection - Gwada Bel

## Email 1 : Premier contact (Approche douce)

**Objet** : 🏝️ Votre villa [NOM VILLA] mérite un site vitrine professionnel

---

Bonjour [Prénom],

Je m'appelle [Votre Nom] et je suis le fondateur de **Gwada Bel**, spécialiste en création de sites vitrines pour locations saisonnières en Guadeloupe.

En parcourant les annonces de locations à [COMMUNE], j'ai remarqué votre magnifique propriété [NOM/TYPE DE BIEN].

**Saviez-vous qu'un site vitrine dédié peut :**
- Augmenter vos réservations directes de 40%
- Réduire votre dépendance aux plateformes (Airbnb, Booking...)
- Valoriser l'image de votre bien
- Vous permettre de fixer vos propres tarifs

J'ai créé **3 exemples concrets** de sites adaptés à différents styles de propriétés en Guadeloupe :

🏆 **Style Luxe** : villa-azur-gwada.vercel.app  
🌴 **Style Créole** : case-ti-paradis.vercel.app  
🏙️ **Style Moderne** : urban-loft-gwada.vercel.app

*(Remplacez par vos vraies URLs une fois déployé)*

**Chaque site inclut :**
- Design professionnel responsive (mobile + desktop)
- Système de réservation avec calendrier
- WhatsApp + Chat en direct
- Galerie photo attractive
- Optimisation SEO pour Google

**Tarifs Lancement Février** : À partir de 350€ (au lieu de 750€)  
Livraison en 7 jours | Hébergement inclus la 1ère année

Seriez-vous disponible pour un échange de 15 minutes cette semaine ?

Bien cordialement,

[Votre Nom]  
**Gwada Bel** - Sites vitrines locations saisonnières  
📱 +590 690 97 73 78  
📧 gwadabelofficiel@gmail.com  
🌐 [Votre site principal quand créé]

---

## Email 2 : Follow-up (7 jours après)

**Objet** : Re : Votre villa [NOM VILLA] - Avez-vous eu le temps de voir ?

---

Bonjour [Prénom],

Je reviens vers vous concernant mon message de la semaine dernière sur la création d'un site vitrine pour votre [TYPE DE BIEN] à [COMMUNE].

Je comprends que vous soyez occupé(e), surtout en haute saison ! 

**Question rapide** : Avez-vous eu l'occasion de jeter un œil aux 3 exemples que je vous ai partagés ?

- Villa luxe : villa-azur-gwada.vercel.app
- Case créole : case-ti-paradis.vercel.app  
- Loft moderne : urban-loft-gwada.vercel.app

Si le timing n'est pas bon en ce moment, je peux vous recontacter en mars/avril pour la préparation de la saison prochaine.

Ou si vous préférez, je peux vous envoyer un **mock-up personnalisé** de ce que donnerait un site pour votre bien (sans engagement).

Dites-moi ce qui vous conviendrait le mieux !

Bonne journée,

[Votre Nom]  
Gwada Bel  
📱 +590 690 97 73 78

---

## Email 3 : Offre urgence (Dernier email)

**Objet** : ⏰ [PRÉNOM], dernière chance - Offre Février se termine

---

Bonjour [Prénom],

Juste un petit mot pour vous informer que **l'offre spéciale de lancement de Février prend fin ce vendredi**.

Après cette date, les tarifs repasseront à leur prix normal (750€ au lieu de 350€).

**Ce que vous obtenez pour 350€** :
✅ Site vitrine professionnel sur-mesure  
✅ Design adapté au style de votre bien  
✅ Calendrier de réservation intégré  
✅ WhatsApp + Chat en direct  
✅ Hébergement inclus 1 an  
✅ Livraison en 7 jours maximum  
✅ 2 révisions incluses  

**Ce que je vous propose** :
1. Appel de 15 min cette semaine (à votre convenance)
2. Je vous montre concrètement comment ça fonctionnerait pour votre [TYPE DE BIEN]
3. Vous décidez si ça vous intéresse ou pas
4. Zéro pression, zéro engagement

Disponible aujourd'hui ou demain pour en discuter ?

Répondez simplement "OUI" à ce mail ou sur WhatsApp (+590 690 97 73 78) et je vous appelle.

Cordialement,

[Votre Nom]  
Gwada Bel

PS : Si vous ne souhaitez plus recevoir de messages de ma part, répondez simplement "STOP" et je retirerai votre contact. Aucun souci ! 😊

---

## Email 4 : Approche "Référencement Google"

**Objet** : [PRÉNOM], votre villa apparaît-elle sur Google ?

---

Bonjour [Prénom],

Petite question : quand quelqu'un tape "location villa [COMMUNE] Guadeloupe" sur Google, votre propriété apparaît-elle ?

**Si la réponse est non**, vous perdez des centaines de réservations potentielles chaque année.

**La solution ?** Un site vitrine optimisé pour le référencement local.

Chez **Gwada Bel**, on crée des sites vitrines qui :
- Apparaissent sur Google en 2-3 semaines
- Attirent des clients qui cherchent spécifiquement [COMMUNE]
- Convertissent les visiteurs en réservations

**Exemples concrets** de ce qu'on fait :
- Style luxe : villa-azur-gwada.vercel.app
- Style créole : case-ti-paradis.vercel.app
- Style moderne : urban-loft-gwada.vercel.app

**Votre concurrent direct** (celui avec la villa à 200m de la vôtre) a peut-être déjà son site. Vous voulez rester derrière ?

Tarif lancement : 350€ tout compris  
Livraison : 7 jours

Intéressé(e) pour en discuter 15 minutes ?

Bien à vous,

[Votre Nom]  
Gwada Bel  
📱 +590 690 97 73 78

---

## Email 5 : Approche "Témoignage client"

**Objet** : Comment Marie a doublé ses réservations directes en 3 mois

---

Bonjour [Prénom],

Je voulais partager avec vous l'histoire de Marie, propriétaire d'une villa à Sainte-Anne.

**Avant :**
- 70% de ses réservations via Airbnb
- Commission de 18% sur chaque résa
- Calendrier mal synchronisé
- Image pas assez valorisée

**Après 3 mois avec son site Gwada Bel :**
- 65% de réservations directes (via son site)
- Économie de 2 400€ en commissions la première année
- Taux d'occupation +25%
- Meilleure image = tarifs plus élevés

**Son retour** : "Le site s'est rentabilisé en 6 semaines. Maintenant je maîtrise mes réservations et je gagne plus."

Votre [TYPE DE BIEN] à [COMMUNE] pourrait avoir les mêmes résultats.

**Voulez-vous voir comment ?**

Exemples de sites selon votre style :
🏆 Luxe : villa-azur-gwada.vercel.app  
🌴 Créole : case-ti-paradis.vercel.app  
🏙️ Moderne : urban-loft-gwada.vercel.app

Appel de 15 min disponible cette semaine ?

À bientôt,

[Votre Nom]  
Gwada Bel  
📱 +590 690 97 73 78

---

## 💡 CONSEILS D'UTILISATION

### Fréquence d'envoi recommandée :
1. **Email 1** → Premier contact (Jour 0)
2. **Email 2** → Follow-up 1 (Jour 7)
3. **Email 3** → Follow-up 2 urgence (Jour 14)
4. **Email 4 ou 5** → Angle différent (Jour 21)
5. **Arrêter** → Si toujours pas de réponse

### Personnalisation obligatoire :
- Remplacez **[TOUS LES CROCHETS]** par les vraies infos
- Ajoutez le vrai **nom de la villa/propriété** si vous le connaissez
- Mentionnez un **détail spécifique** du bien (piscine, vue, etc.)
- Adaptez le **ton** selon l'âge/profil du propriétaire

### Moments optimaux d'envoi :
- **Mardi/Mercredi** : 9h-10h ou 14h-15h (meilleur taux d'ouverture)
- **Éviter** : Lundi matin, Vendredi après-midi, Week-ends

### Tracking des envois :
Créez un fichier Excel avec :
- Nom du prospect
- Email envoyé (numéro + date)
- Réponse ? (Oui/Non)
- Statut (Intéressé/Pas intéressé/À recontacter)
- Notes

---

## 📱 Template SMS/WhatsApp (Alternative)

**Message court** :

```
Bonjour [Prénom], je suis [Nom] de Gwada Bel. 
Je crée des sites vitrines pour locations saisonnières en Gwada.

Voici 3 exemples selon le style :
- Luxe : villa-azur-gwada.vercel.app
- Créole : case-ti-paradis.vercel.app  
- Moderne : urban-loft-gwada.vercel.app

Tarif lancement : 350€. 
Intéressé(e) pour en discuter ?
```

⚠️ **Attention** : N'envoyez des SMS/WhatsApp QUE si vous avez déjà eu un contact ou si le numéro est public (annonce).

---

## 🎯 Segments de prospects

### Segment 1 : Propriétaires sans site
**Approche** : Email 1 ou 4 (Référencement)  
**Argument clé** : Visibilité + Indépendance

### Segment 2 : Propriétaires avec site moche/vieux
**Approche** : Email 5 (Témoignage)  
**Argument clé** : Modernisation + Meilleure conversion

### Segment 3 : Propriétaires dépendants Airbnb
**Approche** : Email 1 ou 5  
**Argument clé** : Économies commissions + Contrôle

### Segment 4 : Nouveaux propriétaires (6 derniers mois)
**Approche** : Email 1 + Offre spéciale  
**Argument clé** : Lancement optimal dès le départ

---

**Bonne prospection ! 🎯**

*Gwada Bel - gwadabelofficiel@gmail.com*
