# 🔥 VILLA AZUR & OR - TOUT PRÊT À UPLOADER

## 📦 CONTENU DU ZIP :

```
villa-azur-final-complete/
├── index.html          ← HTML complet
├── style.css           ← Tous les styles
├── script.js           ← Toutes les fonctions
└── README.md           ← Ce fichier
```

---

## 🚀 UPLOAD SUR GITHUB - 2 MINUTES :

### 1. Décompresser le ZIP sur votre ordinateur

### 2. Aller sur GitHub :
https://github.com/gwadabelofficiel-png/Location-saisonniere-guadeloupe

### 3. Supprimer l'ancien fichier :
- Cliquer sur `index.html` (l'ancien)
- Icône 🗑️ (poubelle)
- "Commit changes"

### 4. Uploader les 3 nouveaux fichiers :
- "Add file" → "Upload files"
- **Glisser-déposer les 3 fichiers** :
  * index.html
  * style.css
  * script.js
- Commit message : "Version finale complète"
- "Commit changes"

### 5. Attendre 1-2 minutes
Vercel redéploie automatiquement !

### 6. Tester :
https://location-saisonniere-guadeloupe.vercel.app

---

## ✅ CE QUI FONCTIONNE :

- ✅ Vidéo background hero (autoplay)
- ✅ 9 photos galerie (lightbox avec flèches)
- ✅ Fiche technique (12 specs)
- ✅ Services premium (6 services)
- ✅ Carte Google Maps
- ✅ Calendrier réservation (calcul prix auto)
- ✅ 3 témoignages (carousel)
- ✅ Chat widget fonctionnel
- ✅ WhatsApp direct
- ✅ Responsive mobile/tablette/desktop

---

## 🎯 ORDRE DES SECTIONS :

1. Header (vidéo)
2. Galerie photos
3. Fiche technique
4. Services premium
5. Localisation + carte
6. Réservation (calendrier)
7. Témoignages
8. Footer

---

## 📝 NOTES :

**Vidéo** : Utilise une vidéo gratuite Mixkit (resort tropical)
**Photos** : 9 photos Unsplash HD gratuites
**Carte** : Google Maps embed de Saint-François
**Prix** : 850€/nuit + 200€ ménage

**Tout est personnalisé avec vos infos** :
- Tel : +590 690 97 73 78
- Email : gwadabelofficiel@gmail.com
- WhatsApp fonctionnel

---

## 🎉 C'EST PRÊT !

Uploadez sur GitHub et c'est FINI !

**Version** : FINALE v3.0
**Date** : 2 Février 2026
**Qualité** : ⭐⭐⭐⭐⭐
